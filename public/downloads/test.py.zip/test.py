from selenium import webdriver 
import time

driver = webdriver.Firefox()

driver.maximize_window()
driver.get('http://www.baidu.com')



js_clearflag= "window.name = '' ;"
js_setflag = "window.name = window.name + '-'+Date.now();"
js_getflag="return window.name"
js_domready = "return (performance.timing.domContentLoadedEventEnd-performance.timing.navigationStart);"
js_loadtime =  "return (performance.timing.loadEventEnd - performance.timing.navigationStart);"

js_finishtime = "var x = 0;performance.getEntries().forEach(function(v){if(v.responseEnd>x){x =v.responseEnd; };});return x;"


print(driver.execute_script(js_domready))
print(driver.execute_script(js_loadtime))


time.sleep(15)
print(driver.execute_script(js_finishtime))
driver.execute_script(js_clearflag)

driver.execute_script(js_setflag)

driver.find_element_by_id("kw").send_keys("python")
driver.find_element_by_id("su").click()
time.sleep(5)
print(driver.execute_script(js_domready))
print(driver.execute_script(js_loadtime))
print(driver.execute_script(js_finishtime))
driver.execute_script(js_setflag)
print(driver.execute_script(js_getflag))

#driver.quit()
